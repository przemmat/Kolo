﻿namespace kolos.DTO
{
    public class MouseDTO
    {
  
        public string Model { get; set; }
        public int DPI { get; set; }
    }
}

﻿namespace kolos.Model
{
    public class Mouse
    {
        public int Id { get; set; }
        public string Model { get; set; }
        public int DPI { get; set; }
    }
}

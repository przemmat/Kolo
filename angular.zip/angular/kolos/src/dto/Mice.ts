export interface Mouse {
  id: number;
  model: string;
  dPI: number;
}

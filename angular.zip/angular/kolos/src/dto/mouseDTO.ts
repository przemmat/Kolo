export interface MouseDTO {
  model: string;
  dpi: number;
}
